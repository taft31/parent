CREATE TRIGGER XL
BEFORE INSERT
  ON INFORMATION
FOR EACH ROW
  begin select user_sequences.nextval into:New.id from dual;--从序列中拿值放入information的id当中
end;
/
